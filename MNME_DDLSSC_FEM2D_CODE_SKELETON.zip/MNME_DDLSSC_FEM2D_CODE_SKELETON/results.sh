#!/bin/bash
# Script para la extracción de los resultados.
rm -r results
mkdir results
mkdir results/time_PCG
mkdir results/set_up
mkdir results/iterations

for i in $(ls);do
        if [$i = "launch_strong_pure_mpi.sh" | $i = "results" | $i = "results.sh" | $i = "torque_template_strong_pure_mpi.sh" ]
        then
                let i = i + 1
        else
                cat $i/stdout | grep "PCG time">results/time_PCG/$i"_PCG.txt"
                cat $i/stdout | grep "set-up time">results/set_up/$i"_set-up.txt"
                cat $i/stdout | grep "iterations">results/iterations/$i"_iterations.txt"
	fi
done
